# Polymer_seq_deconvolution
This is a repo for polymer informatics based on the NLP model.
